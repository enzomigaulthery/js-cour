let element = document.querySelector("p");

element.addEventListener("click", (event) =>{
element.classList.add("Style1");
element.innerHTML = "Je fais du Python";
})